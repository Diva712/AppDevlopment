package com.example.myquizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    TextView name , que , score_text;
    RadioGroup radiogrp_btn;
    RadioButton ans1,ans2,ans3,ans4;
    Button next,quit;
    int curr_index=0;
    int correct = 0;
    int wrong  = 0;
    int sc = 0;

   // int update_que = 1;


    String questions[] = {
            "Which method can be defind only once in a program ?",
            "Which keyword is used by method to refer to the current object that invoked it ?",
            "Which of these access specifiers can be used for an interface ?",
            "Which of the following is correct way of importing an entire package 'pkg'?",
            "What is the return type of constructor ?"
    };

    String options[] = {
            "finailize method" , "main method" , "static method" , "private method",
            "import" , "this" , "catch", " abstract",
            "public" , "protected" , "priavte" , "All above",
            "import pkg." , "import pkg.*" , "Import pkg.*" , "Import pkg.",
            "int" , "float" , "void" , "None"
    };

    String answers[] = {
            "main method",
            "this",
            "public",
            "import pkg.*",
            "None"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        name = (TextView) findViewById(R.id.recieve_name);
        Intent i = getIntent();
        String msg = i.getStringExtra("msg_name");
        name.setText(msg);

        initview();

        //option selection
        //if select that check correct or wrong
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(radiogrp_btn.getCheckedRadioButtonId()==-1){
                    Toast.makeText(getApplicationContext(), "Please select an option",Toast.LENGTH_SHORT).show();
                }
                else{
                    shownextquestion();
                }
            }
        });

        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext() , FinalActivity.class);
                intent.putExtra("msg_score" , sc);
                intent.putExtra("msg_correct" , correct);
                intent.putExtra("msg_wrong" , wrong);
                startActivity(intent);
            }
        });

    }

    private void shownextquestion() {
         checkAnswer();
        curr_index++;
        if(curr_index<questions.length){
            que.setText(questions[curr_index]);

            ans1.setText(options[curr_index * 4]); //4
            ans2.setText(options[curr_index * 4+1]); // 5
            ans3.setText(options[curr_index * 4+2]); //6
            ans4.setText(options[curr_index * 4+3]); // 7
        }
       // curr_index++;
        radiogrp_btn.clearCheck();
        if(curr_index == questions.length){
            Intent intent = new Intent(getApplicationContext() , FinalActivity.class);
            intent.putExtra("msg_score" , sc);
            intent.putExtra("msg_correct" , correct);
            intent.putExtra("msg_wrong" , wrong);
            startActivity(intent);
        }
    }

    private void checkAnswer() {
        RadioButton check_btn = findViewById(radiogrp_btn.getCheckedRadioButtonId());
        String clickAnswer = check_btn.getText().toString();
        if(clickAnswer.equals(answers[curr_index])){
            correct++;
            sc = sc+1;
            score_text.setText("Score : "+sc);
            Toast.makeText(this, "Correct Answer",Toast.LENGTH_SHORT).show();
        }
        else{
            wrong++;
            Toast.makeText(this, "Wrong Answer",Toast.LENGTH_SHORT).show();
        }
    }

    public void initview(){
        score_text = (TextView)findViewById(R.id.score_text);
        //question_number = (TextView) findViewById(R.id.question_number);
        que = (TextView) findViewById(R.id.question_view);
        radiogrp_btn = (RadioGroup) findViewById(R.id.radio_group);
        ans1 = (RadioButton) findViewById(R.id.option1);
        ans2 = (RadioButton) findViewById(R.id.option2);
        ans3 = (RadioButton) findViewById(R.id.option3);
        ans4 = (RadioButton) findViewById(R.id.option4);
        next = (Button)findViewById(R.id.next_question);
        quit = (Button) findViewById(R.id.quit_quiz);

        que.setText(questions[curr_index]);

        ans1.setText(options[0]);
        ans2.setText(options[1]);
        ans3.setText(options[2]);
        ans4.setText(options[3]);
    }
}