package com.example.myquizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FinalActivity extends AppCompatActivity {

    Button correct , wrong, score,restart;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        correct = (Button) findViewById(R.id.correct_btn);
        wrong = (Button) findViewById(R.id.wrong_btn);
        restart = (Button) findViewById(R.id.restart_btn);
        score = (Button) findViewById(R.id.score_btn);

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext() , MainActivity.class);
                startActivity(i);
            }
        });

        Intent i = getIntent();
        Integer msg1 = i.getIntExtra("msg_score",-1);
        Integer msg2 = i.getIntExtra("msg_correct" , -1);
        Integer msg3 = i.getIntExtra("msg_wrong",-1);
        score.setText("Score : "+msg1);
        correct.setText("Correct : "+msg2);
        wrong.setText("Wrong : "+msg3);


    }
}